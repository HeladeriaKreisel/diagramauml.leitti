# Especificación de Requerimientos de Software - Leitti.app

**Proyecto Integrador:** Leitti.app  
**Integrantes:** Ángel Daniel Cortes García - Tomas Alejandro García Benavides  
**Docente:** Natalia Martínez Rojas  
**Institución:** Universidad de La Salle  
**Contexto de aplicación:** Sector San Francisco, Municipio de Guasca, Cundinamarca  

---

## 1. Introducción y Contexto del Problema

El proyecto **Leitti.app** responde a la problemática socio-técnica y logística que experimentan los pequeños productores lácteos del sector San Francisco en Guasca:
- **Estado Actual (Punto A):** Deterioro de vías rurales, acarreo manual de pesadas cantinas, limitaciones críticas en la cadena de frío (riesgo constante de mermas y descomposición por fallas eléctricas), baja conectividad a internet e incertidumbre en la rentabilidad real de la producción.
- **Estado Deseado (Punto B):** Una plataforma digital accesible e intuitiva que permita llevar el control diario de producción, ventas, costos y capacidad del tanque de refrigeración, facilitando además la solidaridad comunitaria mediante el préstamo de capacidad en tanques de frío ante contingencias.

---

## 2. Requerimientos Funcionales (RF)

Los requerimientos funcionales se encuentran organizados de acuerdo con la arquitectura de navegación y los módulos funcionales de la aplicación (*Inicio*, *Mi finca*, *Leche del día*, *Ventas* y *Red Comunitaria*).

### Módulo 1: Inicio (Dashboard y Métricas en Tiempo Real)
* **RF-01: Visualización de Leche del Día:** El sistema debe calcular y mostrar en la pantalla de inicio el total de litros de leche ordeñados y registrados en la fecha actual (`0 L Leche de hoy`).
* **RF-02: Estimación de Ingreso Diario:** El sistema debe estimar y mostrar el ingreso monetario proyectado del día actual multiplicando los litros registrados hoy por el precio de referencia por litro (`$0 Ingreso estimado hoy`).
* **RF-03: Visualización de Leche Vendida Hoy:** El sistema debe totalizar y mostrar los litros de leche despachados o entregados comercialmente durante el día actual (`0 L Vendida hoy`).
* **RF-04: Acumulado Histórico de Ventas:** El sistema debe mostrar el monto total en pesos ($ COP) de todas las ventas consolidadas históricas (`$0 Ventas acumuladas`).
* **RF-05: Monitor del Tanque de Almacenamiento:** El sistema debe indicar mediante una barra de progreso el porcentaje de ocupación del tanque de frío, señalando los litros actuales y los litros de capacidad restante disponible.

### Módulo 2: Mi Finca y Equipos de Frío
* **RF-06: Gestión de Finca / Predio:** El usuario debe poder registrar y actualizar los datos de su predio: nombre de la finca, vereda (ej: San Francisco), municipio (Guasca) y extensión en hectáreas.
* **RF-07: Configuración del Tanque de Refrigeración:** El sistema debe permitir asociar un tanque de enfriamiento a la finca, especificando su capacidad máxima (en litros) y temperatura de trabajo recomendada (4°C).
* **RF-08: Habilitación de Capacidad Solidaria:** El ganadero debe poder marcar su tanque como "disponible para apoyo comunitario" y fijar un límite de litros que puede recibir temporalmente en caso de emergencia de un vecino.

### Módulo 3: Leche del Día (Control de Producción)
* **RF-09: Registro Diario de Ordeño:** El ganadero debe poder registrar ordeños indicando: fecha, jornada (*Mañana* o *Tarde*), cantidad en litros ordeñados, destino (*Tanque de finca*, *Venta directa* o *Autoconsumo*) y observaciones.
* **RF-10: Actualización Automática de Stock en Frío:** Al registrar un ordeño con destino *Tanque de finca*, el sistema debe sumar automáticamente los litros a la reserva del tanque, validando que no se sobrepase la capacidad máxima instalada.

### Módulo 4: Ventas y Compradores
* **RF-11: Directorio de Compradores y Cooperativas:** El sistema debe permitir registrar y administrar compradores (Cooperativa de Guasca, intermediarios, pasteurizadoras), con su nombre, teléfono, ubicación y precio por litro acordado.
* **RF-12: Registro de Transacciones de Venta:** El ganadero debe poder asentar una venta indicando litros entregados, comprador, precio liquidado por litro y estado del pago (*Pendiente* o *Pagado*). Al confirmarse la venta, el sistema debe descontar los litros correspondientes del tanque de la finca.

### Módulo 5: Finanzas, Costos y Rentabilidad
* **RF-13: Registro de Costos de Producción:** El usuario debe poder registrar gastos operativos clasificados por categorías: alimentación (concentrado, forrajes), sanidad animal (veterinario, vacunas), transporte/flete de cantinas, energía y mantenimiento.
* **RF-14: Cálculo de Balance Financiero y Margen Neto:** El sistema debe comparar las ventas acumuladas frente a la sumatoria de costos registrados, determinando si la actividad lechera es económicamente rentable para el productor.

### Módulo 6: Red Comunitaria y Contingencia Rural (Solidaridad)
* **RF-15: Solicitud de Auxilio por Falla Eléctrica o Sobrecupo:** Un ganadero que sufra un corte eléctrico o daño en su refrigeración debe poder emitir una alerta comunitaria indicando los litros en riesgo.
* **RF-16: Búsqueda y Asignación de Tanques Vecinos:** El sistema debe filtrar a los miembros de la red comunitaria de la vereda que cuenten con espacio de frío disponible y permitir acordar el resguardo temporal de la leche para evitar mermas.

---

## 3. Requerimientos No Funcionales (RNF)

* **RNF-01: Usabilidad Rural y Diseño Inclusivo (Accesibilidad):** La interfaz móvil debe tener una tipografía legible, botones grandes, paleta de colores de alto contraste (verde campestre y textos claros) y lenguaje claro adaptado a campesinos con diferentes niveles de alfabetización digital.
* **RNF-02: Disponibilidad y Modo Offline-First:** Dado que en la vereda San Francisco y zonas aledañas al PNN Chingaza la cobertura de datos móviles es intermitente, la aplicación debe permitir registrar ordeños y ventas en modo local (almacenamiento en caché/LocalStorage) y sincronizar al recuperar señal.
* **RNF-03: Rendimiento y Ligereza:** La aplicación debe iniciar en menos de 2 segundos en dispositivos móviles de gama baja y media habituales en la zona rural.
* **RNF-04: Precisión en Cálculos Numéricos:** Las operaciones de balance financiero, proyecciones monetarias y cubicaje de tanques deben operar sin discrepancias de redondeo y bajo la moneda oficial colombiana ($ COP).
* **RNF-05: Modularidad y Mantenibilidad del Código:** El código fuente debe estructurarse según el paradigma orientado a objetos (POO) en JavaScript estándar (ES6+), separando modelos de datos de los servicios de visualización.
* **RNF-06: Seguridad y Privacidad de Datos:** La información financiera, precios de venta y datos personales de los ganaderos deben estar protegidos y ser únicamente accesibles por el titular o en forma anonimizada para la red comunitaria.
