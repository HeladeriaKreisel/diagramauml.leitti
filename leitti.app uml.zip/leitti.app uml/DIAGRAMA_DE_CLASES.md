# Diagrama de Clases UML - Leitti.app

**Proyecto:** Leitti.app - Sistema Comunitario de Gestión Láctea  
**Autores:** Ángel Daniel Cortes García - Tomas Alejandro García Benavides  
**Materia:** Proyecto Integrador | Docente: Natalia Martínez Rojas  
**Universidad de La Salle**  

---

## 1. Diagrama de Clases en Notación UML (Mermaid)

```mermaid
classDiagram
    direction TB

    class Usuario {
        +String id
        +String nombre
        +String telefono
        +String correo
        +String rol
        +Boolean activo
        +Date fechaRegistro
        +actualizarContacto(nuevoTelefono: String, nuevoCorreo: String) void
        +desactivarCuenta() void
    }

    class Ganadero {
        +String vereda
        +Number precioEstimadoPorLitro
        +List~Finca~ fincas
        +List~RegistroLeche~ registrosLeche
        +List~Venta~ ventas
        +List~CostoProduccion~ costos
        +registrarFinca(finca: Finca) void
        +obtenerFincaPrincipal() Finca
        +registrarProduccionDiaria(litros: Number, jornada: String, destino: String, notas: String) RegistroLeche
        +registrarVenta(litros: Number, precioUnitario: Number, comprador: Comprador, estadoPago: String) Venta
        +registrarCosto(concepto: String, categoria: String, monto: Number, notas: String) CostoProduccion
        +obtenerLecheDeHoy() Number
        +obtenerIngresoEstimadoHoy() Number
        +obtenerLecheVendidaHoy() Number
        +obtenerVentasAcumuladas() Number
        +obtenerCapacidadSolidariaDisponible() Number
        +calcularBalanceFinanciero() Object
    }

    class Finca {
        +String id
        +String nombre
        +String vereda
        +String municipio
        +Number areaHectareas
        +TanqueAlmacenamiento tanque
        +asignarTanque(tanque: TanqueAlmacenamiento) void
        +obtenerEspacioTanque() Number
    }

    class TanqueAlmacenamiento {
        +String id
        +Number capacidadMaxLitros
        +Number litrosActuales
        +Number temperaturaActual
        +Number temperaturaOptima
        +Boolean enServicio
        +Boolean permiteApoyoVecinos
        +Number litrosReservadosVecinos
        +obtenerEspacioDisponible() Number
        +obtenerPorcentajeOcupacion() Number
        +almacenarLeche(litros: Number) Boolean
        +retirarLeche(litros: Number) Boolean
        +configurarApoyoComunitario(habilitar: Boolean, litrosOfrecidos: Number) void
        +actualizarTemperatura(gradosCelsius: Number) void
        +estaEnAlertaTemperatura() Boolean
    }

    class RegistroLeche {
        +String id
        +Number litros
        +String jornada
        +Date fecha
        +String destino
        +String notas
        +calcularIngresoEstimado(precioPorLitro: Number) Number
    }

    class Comprador {
        +String id
        +String nombre
        +String tipo
        +String telefono
        +Number precioBaseLitro
        +String direccion
        +actualizarPrecio(nuevoPrecio: Number) void
    }

    class Venta {
        +String id
        +Number litrosVendidos
        +Number precioUnitario
        +Date fecha
        +String estadoPago
        +Number totalVenta
        +Comprador comprador
        +calcularTotal() Number
        +marcarComoPagada() void
    }

    class CostoProduccion {
        +String id
        +String concepto
        +String categoria
        +Number monto
        +Date fecha
        +String notas
    }

    class SolicitudApoyo {
        +String id
        +String idSolicitante
        +String idReceptor
        +Number litrosRequeridos
        +String motivo
        +Date fechaSolicitud
        +String estado
        +String observaciones
        +aceptar(idReceptor: String) void
        +completar() void
        +rechazar(razon: String) void
    }

    class RedComunitaria {
        +String id
        +String nombreSector
        +List~Ganadero~ miembros
        +List~SolicitudApoyo~ solicitudes
        +unirMiembro(ganadero: Ganadero) void
        +buscarVecinosConCapacidad(litrosNecesarios: Number, idExcluir: String) List~Ganadero~
        +publicarSolicitud(solicitud: SolicitudApoyo) SolicitudApoyo
        +obtenerSolicitudesPendientes() List~SolicitudApoyo~
    }

    class DashboardService {
        <<service>>
        +obtenerMetricasInicio(ganadero: Ganadero)$ Object
    }

    %% Relaciones de Clase y Cardinalidades
    Usuario <|-- Ganadero : Herencia (Generalización)
    Ganadero "1" *-- "1..*" Finca : Posee (Composición)
    Finca "1" *-- "0..1" TanqueAlmacenamiento : Contiene (Composición)
    Ganadero "1" o-- "0..*" RegistroLeche : Registra (Agregación)
    Ganadero "1" o-- "0..*" Venta : Realiza (Agregación)
    Ganadero "1" o-- "0..*" CostoProduccion : Asume (Agregación)
    Venta "0..*" --> "1" Comprador : Liquida con (Asociación)
    RedComunitaria "1" o-- "2..*" Ganadero : Agrupa (Agregación)
    RedComunitaria "1" o-- "0..*" SolicitudApoyo : Gestiona (Agregación)
    SolicitudApoyo ..> Ganadero : Involucra (Dependencia)
    DashboardService ..> Ganadero : Procesa métricas (Dependencia)
```

---

## 2. Descripción Detallada de Clases y Relaciones

### 2.1. Relación de Herencia: `Ganadero` extiende `Usuario`
- **Justificación:** `Usuario` encapsula los datos generales de cuenta (identificador, nombre, teléfono de contacto rural, rol y estado activo). `Ganadero` especializa esta clase para los pequeños productores de Guasca, incorporando el manejo de sus fincas, registros diarios de ordeño, historial de ventas a cooperativas y análisis de costos.

### 2.2. Relación de Composición: `Ganadero` con `Finca`, y `Finca` con `TanqueAlmacenamiento`
- **`Ganadero` 1 ──* 1..\* `Finca`:** Un ganadero puede tener una o más parcelas productivas en la vereda. Si el ganadero se elimina del sistema, la administración de sus predios se extingue con él.
- **`Finca` 1 ──* 0..1 `TanqueAlmacenamiento`:** Cada finca dispone físicamente de su equipo o tanque de refrigeración de leche. La capacidad del tanque está intrínsecamente ligada a la finca.

### 2.3. Relaciones de Agregación: `RegistroLeche`, `Venta`, `CostoProduccion`
- **`Ganadero` 1 ──o 0..\* `RegistroLeche`:** Cada ordeño (mañana/tarde) se documenta como un registro independiente con litros y destino.
- **`Ganadero` 1 ──o 0..\* `Venta`:** Ventas formalizadas ante la cooperativa o compradores particulares.
- **`Ganadero` 1 ──o 0..\* `CostoProduccion`:** Registro de gastos (concentrado, veterinario, transporte en cantinas) para calcular la rentabilidad real.

### 2.4. Relación de Asociación: `Venta` y `Comprador`
- **`Venta` 0..\* ──> 1 `Comprador`:** Cada venta está asociada a un cliente o cooperativa registrada en el sistema, fijando el precio unitario y los términos de liquidación.

### 2.5. Red Comunitaria y Respaldo ante Contingencias: `RedComunitaria` y `SolicitudApoyo`
- **`RedComunitaria` 1 ──o 2..\* `Ganadero`:** Comunidades organizadas en sectores (ej: Vereda San Francisco) que comparten información para auxilio mutuo.
- **`RedComunitaria` 1 ──o 0..\* `SolicitudApoyo`:** Cuando un campesino sufre una falla eléctrica o daño en su refrigerador, publica una solicitud para resguardar litros de leche en el tanque de un vecino cercano antes de que la leche se descomponga (resolviendo la incertidumbre de mermas expuesta en el proyecto).

### 2.6. Servicio de Presentación: `DashboardService`
- Clase de servicio con método estático que toma el estado del ganadero y alimenta en tiempo real la interfaz móvil que se observa en la captura de pantalla:
  1. *Leche de hoy* (litros).
  2. *Ingreso estimado hoy* ($ COP).
  3. *Vendida hoy* (litros).
  4. *Ventas acumuladas* ($ COP).
  5. *Barra de ocupación y espacio restante del tanque de almacenamiento*.
