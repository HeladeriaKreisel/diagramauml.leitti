# Leitti.app - Modelo Orientado a Objetos (UML y JavaScript)

> **"Su leche, sus cuentas y sus compradores en un solo lugar"**  
> Proyecto integrador desarrollado para la comunidad ganadera de la vereda San Francisco, Municipio de Guasca, Cundinamarca.

---

## 👥 Integrantes del Proyecto
* **Ángel Daniel Cortes García**
* **Tomas Alejandro García Benavides**

**Docente:** Natalia Martínez Rojas  
**Asignatura:** Proyecto Integrador  
**Programa:** Ingeniería de Software  
**Institución:** Universidad de La Salle - Bogotá D.C.  
**ODS Impactado:** ODS 9 (Industria, Innovación e Infraestructura)  

---

## 📋 Descripción de la Entrega

Este repositorio contiene la solución completa requerida para la actividad:
1. **Especificación formal de Requerimientos:** Requerimientos Funcionales (RF) y No Funcionales (RNF) correspondientes a cada pantalla y flujo de la aplicación móvil (ver [REQUERIMIENTOS.md](REQUERIMIENTOS.md)).
2. **Diagrama de Clases UML:** Diagrama con relaciones formales (herencia, composición, agregación, asociación y dependencia), atributos tipados y métodos (ver [DIAGRAMA_DE_CLASES.md](DIAGRAMA_DE_CLASES.md)).
3. **Implementación de Clases en JavaScript (ES6+):** Código modular limpio con soporte para la pantalla principal (Dashboard), gestión de fincas, tanques de refrigeración, ordeño diario, ventas, costos y red comunitaria de auxilio por fallas de refrigeración.

---

## 📱 Relación con la Interfaz de Usuario (UI)

La pantalla principal móvil de **Leitti.app** cuenta con las siguientes tarjetas que se alimentan directamente de los métodos de la clase `Ganadero` y el servicio `DashboardService`:

| Componente en UI | Métrica Mostrada | Atributo / Método en JavaScript |
| :--- | :--- | :--- |
| **Tarjeta 1** | `0 L Leche de hoy` | `ganadero.obtenerLecheDeHoy()` |
| **Tarjeta 2** | `$0 Ingreso estimado hoy` | `ganadero.obtenerIngresoEstimadoHoy()` |
| **Tarjeta 3** | `0 L Vendida hoy` | `ganadero.obtenerLecheVendidaHoy()` |
| **Tarjeta 4** | `$0 Ventas acumuladas` | `ganadero.obtenerVentasAcumuladas()` |
| **Sección Tanque** | `Leche en el tanque (Barra de progreso)` | `tanque.obtenerPorcentajeOcupacion()`, `tanque.obtenerEspacioDisponible()` |
| **Navegación Inferior** | `Inicio`, `Mi finca`, `Leche del día`, `Ventas` | Modelados en `Finca.js`, `RegistroLeche.js` y `Venta.js` |

---

## 📊 Diagrama de Clases UML (Mermaid)

GitHub renderiza este diagrama de forma nativa a continuación:

```mermaid
classDiagram
    direction TB

    class Usuario {
        +String id
        +String nombre
        +String telefono
        +String correo
        +String rol
        +Boolean activo
        +Date fechaRegistro
        +actualizarContacto(nuevoTelefono: String, nuevoCorreo: String) void
        +desactivarCuenta() void
    }

    class Ganadero {
        +String vereda
        +Number precioEstimadoPorLitro
        +List~Finca~ fincas
        +List~RegistroLeche~ registrosLeche
        +List~Venta~ ventas
        +List~CostoProduccion~ costos
        +registrarFinca(finca: Finca) void
        +obtenerFincaPrincipal() Finca
        +registrarProduccionDiaria(litros: Number, jornada: String, destino: String, notas: String) RegistroLeche
        +registrarVenta(litros: Number, precioUnitario: Number, comprador: Comprador, estadoPago: String) Venta
        +registrarCosto(concepto: String, categoria: String, monto: Number, notas: String) CostoProduccion
        +obtenerLecheDeHoy() Number
        +obtenerIngresoEstimadoHoy() Number
        +obtenerLecheVendidaHoy() Number
        +obtenerVentasAcumuladas() Number
        +obtenerCapacidadSolidariaDisponible() Number
        +calcularBalanceFinanciero() Object
    }

    class Finca {
        +String id
        +String nombre
        +String vereda
        +String municipio
        +Number areaHectareas
        +TanqueAlmacenamiento tanque
        +asignarTanque(tanque: TanqueAlmacenamiento) void
        +obtenerEspacioTanque() Number
    }

    class TanqueAlmacenamiento {
        +String id
        +Number capacidadMaxLitros
        +Number litrosActuales
        +Number temperaturaActual
        +Number temperaturaOptima
        +Boolean enServicio
        +Boolean permiteApoyoVecinos
        +Number litrosReservadosVecinos
        +obtenerEspacioDisponible() Number
        +obtenerPorcentajeOcupacion() Number
        +almacenarLeche(litros: Number) Boolean
        +retirarLeche(litros: Number) Boolean
        +configurarApoyoComunitario(habilitar: Boolean, litrosOfrecidos: Number) void
        +actualizarTemperatura(gradosCelsius: Number) void
        +estaEnAlertaTemperatura() Boolean
    }

    class RegistroLeche {
        +String id
        +Number litros
        +String jornada
        +Date fecha
        +String destino
        +String notas
        +calcularIngresoEstimado(precioPorLitro: Number) Number
    }

    class Comprador {
        +String id
        +String nombre
        +String tipo
        +String telefono
        +Number precioBaseLitro
        +String direccion
        +actualizarPrecio(nuevoPrecio: Number) void
    }

    class Venta {
        +String id
        +Number litrosVendidos
        +Number precioUnitario
        +Date fecha
        +String estadoPago
        +Number totalVenta
        +Comprador comprador
        +calcularTotal() Number
        +marcarComoPagada() void
    }

    class CostoProduccion {
        +String id
        +String concepto
        +String categoria
        +Number monto
        +Date fecha
        +String notas
    }

    class SolicitudApoyo {
        +String id
        +String idSolicitante
        +String idReceptor
        +Number litrosRequeridos
        +String motivo
        +Date fechaSolicitud
        +String estado
        +String observaciones
        +aceptar(idReceptor: String) void
        +completar() void
        +rechazar(razon: String) void
    }

    class RedComunitaria {
        +String id
        +String nombreSector
        +List~Ganadero~ miembros
        +List~SolicitudApoyo~ solicitudes
        +unirMiembro(ganadero: Ganadero) void
        +buscarVecinosConCapacidad(litrosNecesarios: Number, idExcluir: String) List~Ganadero~
        +publicarSolicitud(solicitud: SolicitudApoyo) SolicitudApoyo
        +obtenerSolicitudesPendientes() List~SolicitudApoyo~
    }

    class DashboardService {
        <<service>>
        +obtenerMetricasInicio(ganadero: Ganadero)$ Object
    }

    %% Relaciones
    Usuario <|-- Ganadero : Herencia (Generalización)
    Ganadero "1" *-- "1..*" Finca : Posee (Composición)
    Finca "1" *-- "0..1" TanqueAlmacenamiento : Contiene (Composición)
    Ganadero "1" o-- "0..*" RegistroLeche : Registra (Agregación)
    Ganadero "1" o-- "0..*" Venta : Realiza (Agregación)
    Ganadero "1" o-- "0..*" CostoProduccion : Asume (Agregación)
    Venta "0..*" --> "1" Comprador : Liquida con (Asociación)
    RedComunitaria "1" o-- "2..*" Ganadero : Agrupa (Agregación)
    RedComunitaria "1" o-- "0..*" SolicitudApoyo : Gestiona (Agregación)
    SolicitudApoyo ..> Ganadero : Involucra (Dependencia)
    DashboardService ..> Ganadero : Procesa métricas (Dependencia)
```

---

## 🗂 Estructura del Proyecto

```text
leitti.app uml/
│
├── DIAGRAMA_DE_CLASES.md    # Diagrama UML en Mermaid y descripción detallada
├── REQUERIMIENTOS.md         # Requerimientos funcionales y no funcionales (RF y RNF)
├── README.md                 # Documentación general y guía de entrega
├── package.json              # Configuración del paquete JavaScript
│
└── src/
    ├── index.js              # Script demostrativo con casos de uso de la app
    │
    ├── models/
    │   ├── Usuario.js               # Clase base de usuarios
    │   ├── Ganadero.js              # Productor campesino (hereda de Usuario)
    │   ├── Finca.js                 # Predio rural en Guasca
    │   ├── TanqueAlmacenamiento.js  # Tanque de frío y reserva solidaria
    │   ├── RegistroLeche.js         # Módulo "Leche del día" (mañana/tarde)
    │   ├── Comprador.js             # Cooperativa o comprador particular
    │   ├── Venta.js                 # Transacción comercial ("Ventas")
    │   ├── CostoProduccion.js       # Insumos, transporte, sanidad
    │   ├── SolicitudApoyo.js        # Contingencia por corte eléctrico
    │   └── RedComunitaria.js        # Red comunitaria de la vereda
    │
    └── services/
        └── DashboardService.js      # Formateador de datos para pantalla "Inicio"
```

---

## 🚀 Pasos para Subir este Proyecto a GitHub

Para cumplir con el enlace solicitado en la plataforma de entrega:

1. **Abrir la consola en la carpeta del proyecto** (`c:\Users\User\Desktop\leitti.app uml`).
2. **Crear un nuevo repositorio en tu cuenta de GitHub** (ejemplo: `leitti-app-uml-js`).
3. **Ejecutar los siguientes comandos en tu terminal:**

```bash
# 1. Agregar todos los archivos al commit
git add .

# 2. Realizar el commit inicial
git commit -m "feat: implementacion de requerimientos, diagrama de clases UML y modelos en JavaScript para Leitti.app"

# 3. Renombrar la rama a main
git branch -M main

# 4. Vincular con tu repositorio de GitHub (reemplaza con tu URL)
git remote add origin https://github.com/TU-USUARIO/leitti-app-uml-js.git

# 5. Subir los cambios a GitHub
git push -u origin main
```

4. **Copiar el enlace del repositorio** y subirlo a la plataforma virtual junto con el diagrama de clases o el archivo PDF/Markdown.
