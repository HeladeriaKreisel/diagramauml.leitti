/**
 * @file index.js
 * @description Script de demostración interactiva de las clases y lógica de negocio de Leitti.app.
 * Modela el flujo completo: registro de finca y tanque, ordeño diario, ventas, costos,
 * cálculo del dashboard (coincidente con la UI) y cooperación comunitaria en Guasca.
 */

import { Ganadero } from './models/Ganadero.js';
import { Finca } from './models/Finca.js';
import { TanqueAlmacenamiento } from './models/TanqueAlmacenamiento.js';
import { Comprador } from './models/Comprador.js';
import { RedComunitaria } from './models/RedComunitaria.js';
import { SolicitudApoyo } from './models/SolicitudApoyo.js';
import { DashboardService } from './services/DashboardService.js';

console.log('================================================================');
console.log('       LEITTI.APP - SISTEMA DE GESTIÓN GANADERA (GUASCA)         ');
console.log('    "Su leche, sus cuentas y sus compradores en un solo lugar"   ');
console.log('================================================================\n');

// 1. Instanciar Ganadero
const donPedro = new Ganadero(
  'CC-10203040',
  'Pedro Nel Rodríguez',
  '3101234567',
  'San Francisco',
  1950 // Precio estimado por litro COP
);

console.log('1. ESTADO INICIAL (Pantalla "Inicio" sin finca ni registros):');
console.log(DashboardService.obtenerMetricasInicio(donPedro));
console.log('----------------------------------------------------------------\n');

// 2. Registro de Finca y Tanque de Almacenamiento (Módulo "Mi finca")
console.log('2. REGISTRO DE PREDIO Y TANQUE DE FRÍO (Módulo "Mi finca"):');
const fincaLaEsperanza = new Finca(
  'FINC-01',
  'Finca La Esperanza',
  'San Francisco',
  'Guasca',
  8.5
);

// Tanque de 1000 Litros con temperatura óptima de 4°C
const tanqueFinca = new TanqueAlmacenamiento('TNQ-1000', 1000, 4.0);
tanqueFinca.configurarApoyoComunitario(true, 250); // Habilita hasta 250 L para auxilio a vecinos

fincaLaEsperanza.asignarTanque(tanqueFinca);
donPedro.registrarFinca(fincaLaEsperanza);

console.log(`- Finca registrada: ${fincaLaEsperanza.nombre} en vereda ${fincaLaEsperanza.vereda}`);
console.log(`- Tanque asignado: ${tanqueFinca.capacidadMaxLitros} L | Disponible: ${tanqueFinca.obtenerEspacioDisponible()} L`);
console.log('----------------------------------------------------------------\n');

// 3. Registro de Producción Diaria (Módulo "Leche del día")
console.log('3. REGISTRO DE PRODUCCIÓN DIARIA (Módulo "Leche del día"):');
const ordenoManana = donPedro.registrarProduccionDiaria(180, 'manana', 'tanque_finca', 'Ordeño normal matutino');
const ordenoTarde = donPedro.registrarProduccionDiaria(120, 'tarde', 'tanque_finca', 'Ordeño vespertino');
console.log(`- Ordeño mañana: ${ordenoManana.litros} L`);
console.log(`- Ordeño tarde: ${ordenoTarde.litros} L`);
console.log(`- Total leche recolectada hoy: ${donPedro.obtenerLecheDeHoy()} L`);
console.log(`- Nivel actual en el tanque: ${tanqueFinca.litrosActuales} L / ${tanqueFinca.capacidadMaxLitros} L (${tanqueFinca.obtenerPorcentajeOcupacion()}%)`);
console.log('----------------------------------------------------------------\n');

// 4. Muestra del Dashboard actualizado tras ordeño
console.log('4. MÉTRICAS VISUALIZADAS EN EL DASHBOARD TRAS ORDEÑO:');
console.log(DashboardService.obtenerMetricasInicio(donPedro));
console.log('----------------------------------------------------------------\n');

// 5. Registro de Compradores y Ventas (Módulo "Ventas")
console.log('5. REGISTRO DE COMPRADOR Y TRANSACCIÓN DE VENTA (Módulo "Ventas"):');
const cooperativaGuasca = new Comprador(
  'COMP-01',
  'Cooperativa de Productores Lácteos de Guasca',
  'cooperativa',
  '3209876543',
  1950,
  'Plaza Central Guasca'
);

// Venta de 250 Litros a la cooperativa
const ventaHoy = donPedro.registrarVenta(250, 1950, cooperativaGuasca, 'pagado');
console.log(`- Venta realizada a: ${ventaHoy.comprador.nombre}`);
console.log(`- Litros entregados: ${ventaHoy.litrosVendidos} L`);
console.log(`- Total cobrado: $${ventaHoy.totalVenta.toLocaleString('es-CO')} COP`);
console.log(`- Tanque luego de despachar la venta: ${tanqueFinca.litrosActuales} L en reserva`);
console.log('----------------------------------------------------------------\n');

// 6. Registro de Costos de Producción y Balance de Rentabilidad
console.log('6. ANÁLISIS ECONÓMICO Y DE RENTABILIDAD (Resolución a la incertidumbre de mermas/costos):');
donPedro.registrarCosto('Bulto de concentrado lechero', 'alimentacion', 115000);
donPedro.registrarCosto('Control veterinario y vitaminas', 'salud_veterinaria', 60000);
donPedro.registrarCosto('Flete y desinfección de cantinas', 'transporte', 45000);

const balance = donPedro.calcularBalanceFinanciero();
console.log(`- Total Ingresos: $${balance.totalIngresos.toLocaleString('es-CO')} COP`);
console.log(`- Total Costos Registrados: $${balance.totalCostos.toLocaleString('es-CO')} COP`);
console.log(`- Utilidad Neta: $${balance.utilidadNeta.toLocaleString('es-CO')} COP`);
console.log(`- ¿La actividad lechera es rentable?: ${balance.esRentable ? 'SÍ, RENTABLE' : 'NO, EN DÉFICIT'}`);
console.log('----------------------------------------------------------------\n');

// 7. Simulación de Red Comunitaria y Contingencia (Punto B: Apoyo solidario por corte eléctrico)
console.log('7. RED COMUNITARIA Y AUXILIO POR FALLA ELÉCTRICA EN LA VEREDA:');
const redSanFrancisco = new RedComunitaria('RED-SF', 'Red Lechera Vereda San Francisco');
redSanFrancisco.unirMiembro(donPedro);

// Vecino que sufre falla eléctrica en su refrigerador
const vecinoDonCarlos = new Ganadero('CC-556677', 'Carlos Gómez', '3124455667', 'San Francisco');
redSanFrancisco.unirMiembro(vecinoDonCarlos);

// Don Carlos publica solicitud de auxilio para 150 litros en riesgo de descomposición
const solicitudEmergencia = new SolicitudApoyo(
  'SOL-001',
  vecinoDonCarlos.id,
  150,
  'corte_electrico',
  new Date()
);
redSanFrancisco.publicarSolicitud(solicitudEmergencia);
console.log(`- Emergencia reportada: Don Carlos necesita refrigerar ${solicitudEmergencia.litrosRequeridos} L por corte eléctrico.`);

// El sistema busca vecinos con espacio disponible en frío
const vecinosDisponibles = redSanFrancisco.buscarVecinosConCapacidad(solicitudEmergencia.litrosRequeridos, vecinoDonCarlos.id);
console.log(`- Vecinos con capacidad de frío para apoyar: ${vecinosDisponibles.map((v) => v.nombre).join(', ')}`);

if (vecinosDisponibles.length > 0) {
  solicitudEmergencia.aceptar(donPedro.id);
  // Se almacena la leche del vecino en el tanque de Don Pedro para no perderla
  tanqueFinca.almacenarLeche(solicitudEmergencia.litrosRequeridos);
  solicitudEmergencia.completar();
  console.log(`- ¡Auxilio exitoso! Don Pedro acogió ${solicitudEmergencia.litrosRequeridos} L de leche en su tanque.`);
  console.log(`- Estado actual del tanque solidario: ${tanqueFinca.litrosActuales} L / ${tanqueFinca.capacidadMaxLitros} L.`);
}

console.log('----------------------------------------------------------------\n');
console.log('8. DASHBOARD FINAL COMPLETO (INICIO):');
console.log(DashboardService.obtenerMetricasInicio(donPedro));
console.log('\n================================================================');
console.log('         DEMOSTRACIÓN DE LEITTI.APP FINALIZADA CON ÉXITO        ');
console.log('================================================================');
