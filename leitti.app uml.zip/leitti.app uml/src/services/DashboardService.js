/**
 * @file DashboardService.js
 * @description Servicio encargado de calcular y estructurar la información del Dashboard principal
 * tal como se visualiza en la interfaz de usuario de Leitti.app.
 */

export class DashboardService {
  /**
   * Genera el estado de las 4 tarjetas principales y la barra de estado del tanque.
   * @param {import('../models/Ganadero.js').Ganadero} ganadero
   * @returns {object} Datos formateados para la pantalla de "Inicio".
   */
  static obtenerMetricasInicio(ganadero) {
    if (!ganadero) {
      return {
        lecheDeHoy: '0 L',
        ingresoEstimadoHoy: '$0',
        vendidaHoy: '0 L',
        ventasAcumuladas: '$0',
        tanque: {
          registrado: false,
          mensaje: 'Registre su finca y la leche de hoy para ver cuánto espacio le queda.',
          porcentajeOcupado: 0,
          litrosActuales: 0,
          capacidadMaxLitros: 0,
          espacioRestante: 0,
        },
      };
    }

    const litrosHoy = ganadero.obtenerLecheDeHoy();
    const ingresoHoy = ganadero.obtenerIngresoEstimadoHoy();
    const vendidaHoy = ganadero.obtenerLecheVendidaHoy();
    const acumuladas = ganadero.obtenerVentasAcumuladas();

    const finca = ganadero.obtenerFincaPrincipal();
    const tanque = finca ? finca.tanque : null;

    let tanqueInfo = {
      registrado: false,
      mensaje: 'Registre su finca y la leche de hoy para ver cuánto espacio le queda.',
      porcentajeOcupado: 0,
      litrosActuales: 0,
      capacidadMaxLitros: 0,
      espacioRestante: 0,
    };

    if (tanque) {
      const espacioLibre = tanque.obtenerEspacioDisponible();
      tanqueInfo = {
        registrado: true,
        litrosActuales: tanque.litrosActuales,
        capacidadMaxLitros: tanque.capacidadMaxLitros,
        espacioRestante: espacioLibre,
        porcentajeOcupado: tanque.obtenerPorcentajeOcupacion(),
        mensaje: `Tanque al ${tanque.obtenerPorcentajeOcupacion()}% de capacidad (${espacioLibre} L disponibles).`,
      };
    }

    return {
      lecheDeHoy: `${litrosHoy.toLocaleString('es-CO')} L`,
      ingresoEstimadoHoy: `$${ingresoHoy.toLocaleString('es-CO')}`,
      vendidaHoy: `${vendidaHoy.toLocaleString('es-CO')} L`,
      ventasAcumuladas: `$${acumuladas.toLocaleString('es-CO')}`,
      tanque: tanqueInfo,
    };
  }
}
