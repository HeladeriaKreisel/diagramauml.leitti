/**
 * @file TanqueAlmacenamiento.js
 * @description Modela el tanque o equipo de refrigeración de leche de la finca.
 * Permite monitorear la capacidad, temperatura y habilitar espacio solidario para vecinos.
 */

export class TanqueAlmacenamiento {
  /**
   * @param {string} id - Identificador del tanque.
   * @param {number} capacidadMaxLitros - Capacidad máxima en litros.
   * @param {number} temperaturaOptima - Temperatura recomendada de conservación en °C (ej: 4°C).
   */
  constructor(id, capacidadMaxLitros, temperaturaOptima = 4.0) {
    this.id = String(id);
    this.capacidadMaxLitros = Number(capacidadMaxLitros);
    this.litrosActuales = 0;
    this.temperaturaActual = temperaturaOptima;
    this.temperaturaOptima = Number(temperaturaOptima);
    this.enServicio = true;
    this.permiteApoyoVecinos = false;
    this.litrosReservadosVecinos = 0;
  }

  /**
   * Retorna los litros de capacidad libre en el tanque.
   * @returns {number}
   */
  obtenerEspacioDisponible() {
    const disponible = this.capacidadMaxLitros - this.litrosActuales;
    return disponible > 0 ? disponible : 0;
  }

  /**
   * Retorna el porcentaje de ocupación del tanque (0 a 100).
   * @returns {number}
   */
  obtenerPorcentajeOcupacion() {
    if (this.capacidadMaxLitros === 0) return 0;
    return Math.min(100, Math.round((this.litrosActuales / this.capacidadMaxLitros) * 100));
  }

  /**
   * Ingresa litros de leche al tanque.
   * @param {number} litros
   * @returns {boolean} Retorna true si se almacenó con éxito.
   */
  almacenarLeche(litros) {
    const cantidad = Number(litros);
    if (cantidad <= 0) {
      throw new Error('La cantidad de leche a ingresar debe ser mayor a 0 litros.');
    }
    if (this.litrosActuales + cantidad > this.capacidadMaxLitros) {
      throw new Error(`Capacidad insuficiente en el tanque. Disponible: ${this.obtenerEspacioDisponible()} L, intentando ingresar: ${cantidad} L.`);
    }
    this.litrosActuales += cantidad;
    return true;
  }

  /**
   * Retira leche del tanque (ej: para despacho, venta o traslado).
   * @param {number} litros
   * @returns {boolean}
   */
  retirarLeche(litros) {
    const cantidad = Number(litros);
    if (cantidad <= 0) {
      throw new Error('La cantidad a retirar debe ser mayor a 0.');
    }
    if (cantidad > this.litrosActuales) {
      throw new Error(`No hay suficiente leche en el tanque. Actual: ${this.litrosActuales} L.`);
    }
    this.litrosActuales -= cantidad;
    return true;
  }

  /**
   * Habilita o deshabilita la disponibilidad del tanque para apoyar a vecinos en contingencias.
   * @param {boolean} habilitar
   * @param {number} litrosOfrecidos
   */
  configurarApoyoComunitario(habilitar, litrosOfrecidos = 0) {
    this.permiteApoyoVecinos = Boolean(habilitar);
    if (this.permiteApoyoVecinos) {
      const maxDisponible = this.obtenerEspacioDisponible();
      this.litrosReservadosVecinos = Math.min(Number(litrosOfrecidos), maxDisponible);
    } else {
      this.litrosReservadosVecinos = 0;
    }
  }

  /**
   * Registra una medición de temperatura del tanque.
   * @param {number} gradosCelsius
   */
  actualizarTemperatura(gradosCelsius) {
    this.temperaturaActual = Number(gradosCelsius);
  }

  /**
   * Indica si la temperatura actual está en riesgo de descomponer la leche (> 6°C a 8°C).
   * @returns {boolean}
   */
  estaEnAlertaTemperatura() {
    return this.temperaturaActual > 6.0;
  }
}
