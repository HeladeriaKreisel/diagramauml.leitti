/**
 * @file SolicitudApoyo.js
 * @description Modela una solicitud solidaria entre ganaderos vecinos para compartir capacidad
 * de refrigeración en tanque ante cortes eléctricos o imprevistos de conservación.
 */

export class SolicitudApoyo {
  /**
   * @param {string} id - Identificador de la solicitud.
   * @param {string} idSolicitante - ID o nombre del ganadero que necesita ayuda.
   * @param {number} litrosRequeridos - Cantidad de leche en riesgo.
   * @param {string} motivo - 'corte_electrico', 'sobrecupo', 'dano_equipo', 'otro'.
   * @param {Date|string} fechaSolicitud - Fecha y hora de emisión.
   */
  constructor(id, idSolicitante, litrosRequeridos, motivo = 'corte_electrico', fechaSolicitud = new Date()) {
    this.id = String(id);
    this.idSolicitante = String(idSolicitante);
    this.litrosRequeridos = Number(litrosRequeridos);
    this.motivo = String(motivo);
    this.fechaSolicitud = fechaSolicitud instanceof Date ? fechaSolicitud : new Date(fechaSolicitud);
    this.idReceptor = null; // Ganadero que brinda el auxilio
    this.estado = 'pendiente'; // 'pendiente' | 'aceptada' | 'rechazada' | 'completada'
    this.observaciones = '';
  }

  /**
   * Un ganadero vecino acepta acoger la leche en su tanque de refrigeración.
   * @param {string} idReceptor - Identificador del ganadero voluntario.
   */
  aceptar(idReceptor) {
    this.idReceptor = String(idReceptor);
    this.estado = 'aceptada';
  }

  /**
   * Marca la transferencia como culminada satisfactoriamente.
   */
  completar() {
    this.estado = 'completada';
  }

  /**
   * Rechaza o cancela la solicitud.
   * @param {string} razon
   */
  rechazar(razon = '') {
    this.estado = 'rechazada';
    this.observaciones = razon;
  }
}
