/**
 * @file Venta.js
 * @description Modela una transacción de venta de leche (módulo "Ventas").
 */

import { Comprador } from './Comprador.js';

export class Venta {
  /**
   * @param {string} id - Identificador de la venta.
   * @param {number} litrosVendidos - Cantidad de litros vendidos.
   * @param {number} precioUnitario - Precio por litro liquidado ($ COP).
   * @param {Comprador} comprador - Objeto comprador receptor.
   * @param {Date|string} fecha - Fecha y hora de la venta.
   * @param {string} estadoPago - 'pendiente' o 'pagado'.
   */
  constructor(id, litrosVendidos, precioUnitario, comprador, fecha = new Date(), estadoPago = 'pagado') {
    this.id = String(id);
    this.litrosVendidos = Number(litrosVendidos);
    this.precioUnitario = Number(precioUnitario);
    this.comprador = comprador instanceof Comprador ? comprador : null;
    this.fecha = fecha instanceof Date ? fecha : new Date(fecha);
    this.estadoPago = String(estadoPago); // 'pendiente' | 'pagado'
    this.totalVenta = this.calcularTotal();
  }

  /**
   * Calcula el total liquidado de la venta.
   * @returns {number}
   */
  calcularTotal() {
    this.totalVenta = this.litrosVendidos * this.precioUnitario;
    return this.totalVenta;
  }

  /**
   * Marca la transacción como cobrada.
   */
  marcarComoPagada() {
    this.estadoPago = 'pagado';
  }
}
