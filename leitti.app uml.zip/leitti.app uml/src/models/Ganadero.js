/**
 * @file Ganadero.js
 * @description Modela al productor campesino lechero, usuario principal de Leitti.app.
 * Hereda de Usuario y centraliza sus fincas, producción diaria, ventas y costos.
 */

import { Usuario } from './Usuario.js';
import { Finca } from './Finca.js';
import { RegistroLeche } from './RegistroLeche.js';
import { Venta } from './Venta.js';
import { CostoProduccion } from './CostoProduccion.js';

export class Ganadero extends Usuario {
  /**
   * @param {string} id - Cédula o identificador.
   * @param {string} nombre - Nombre del productor.
   * @param {string} telefono - Teléfono de contacto.
   * @param {string} vereda - Vereda de residencia (ej: "San Francisco").
   * @param {number} precioEstimadoPorLitro - Precio de referencia por litro ($ COP) para proyecciones.
   */
  constructor(id, nombre, telefono, vereda = 'San Francisco', precioEstimadoPorLitro = 1900) {
    super(id, nombre, telefono, '', 'ganadero');
    this.vereda = String(vereda);
    this.precioEstimadoPorLitro = Number(precioEstimadoPorLitro);

    /** @type {Array<Finca>} */
    this.fincas = [];
    /** @type {Array<RegistroLeche>} */
    this.registrosLeche = [];
    /** @type {Array<Venta>} */
    this.ventas = [];
    /** @type {Array<CostoProduccion>} */
    this.costos = [];
  }

  /**
   * Registra una finca al perfil del ganadero.
   * @param {Finca} finca
   */
  registrarFinca(finca) {
    if (!(finca instanceof Finca)) {
      throw new Error('Debe ser una instancia válida de Finca.');
    }
    this.fincas.push(finca);
  }

  /**
   * Obtiene la finca activa o primera finca registrada.
   * @returns {Finca|null}
   */
  obtenerFincaPrincipal() {
    return this.fincas.length > 0 ? this.fincas[0] : null;
  }

  /**
   * Registra la producción de leche de la jornada e incrementa el tanque si aplica.
   * @param {number} litros
   * @param {string} jornada - 'manana' | 'tarde'
   * @param {string} destino - 'tanque_finca' | 'venta_directa' | 'autoconsumo'
   * @param {string} notas
   * @returns {RegistroLeche}
   */
  registrarProduccionDiaria(litros, jornada = 'manana', destino = 'tanque_finca', notas = '') {
    const idRegistro = `REG-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const nuevoRegistro = new RegistroLeche(idRegistro, litros, jornada, new Date(), destino, notas);
    this.registrosLeche.push(nuevoRegistro);

    // Si el destino es el tanque de la finca y tiene tanque configurado, se almacena
    if (destino === 'tanque_finca') {
      const finca = this.obtenerFincaPrincipal();
      if (finca && finca.tanque) {
        finca.tanque.almacenarLeche(litros);
      }
    }
    return nuevoRegistro;
  }

  /**
   * Registra una venta de leche y descuenta del tanque si es pertinente.
   * @param {number} litros
   * @param {number} precioUnitario
   * @param {import('./Comprador.js').Comprador} comprador
   * @param {string} estadoPago
   * @returns {Venta}
   */
  registrarVenta(litros, precioUnitario, comprador, estadoPago = 'pagado') {
    const idVenta = `VTA-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const nuevaVenta = new Venta(idVenta, litros, precioUnitario, comprador, new Date(), estadoPago);
    this.ventas.push(nuevaVenta);

    // Descontar litros del tanque de la finca
    const finca = this.obtenerFincaPrincipal();
    if (finca && finca.tanque && finca.tanque.litrosActuales >= litros) {
      finca.tanque.retirarLeche(litros);
    }

    return nuevaVenta;
  }

  /**
   * Registra un egreso o costo operacional asociado a la producción.
   * @param {string} concepto
   * @param {string} categoria
   * @param {number} monto
   * @param {string} notas
   * @returns {CostoProduccion}
   */
  registrarCosto(concepto, categoria, monto, notas = '') {
    const idCosto = `CST-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const nuevoCosto = new CostoProduccion(idCosto, concepto, categoria, monto, new Date(), notas);
    this.costos.push(nuevoCosto);
    return nuevoCosto;
  }

  /**
   * Retorna la cantidad total de leche producida hoy (Tarjeta 1 de Dashboard: "0 L Leche de hoy").
   * @returns {number}
   */
  obtenerLecheDeHoy() {
    const hoyStr = new Date().toISOString().slice(0, 10);
    return this.registrosLeche
      .filter((r) => r.fecha.toISOString().slice(0, 10) === hoyStr)
      .reduce((acumulado, r) => acumulado + r.litros, 0);
  }

  /**
   * Retorna el ingreso proyectado para la leche producida hoy (Tarjeta 2: "$0 Ingreso estimado hoy").
   * @returns {number}
   */
  obtenerIngresoEstimadoHoy() {
    const litrosHoy = this.obtenerLecheDeHoy();
    return litrosHoy * this.precioEstimadoPorLitro;
  }

  /**
   * Retorna los litros vendidos en la fecha de hoy (Tarjeta 3: "0 L Vendida hoy").
   * @returns {number}
   */
  obtenerLecheVendidaHoy() {
    const hoyStr = new Date().toISOString().slice(0, 10);
    return this.ventas
      .filter((v) => v.fecha.toISOString().slice(0, 10) === hoyStr)
      .reduce((acumulado, v) => acumulado + v.litrosVendidos, 0);
  }

  /**
   * Retorna la suma total de ventas históricas acumuladas (Tarjeta 4: "$0 Ventas acumuladas").
   * @returns {number}
   */
  obtenerVentasAcumuladas() {
    return this.ventas.reduce((acumulado, v) => acumulado + v.totalVenta, 0);
  }

  /**
   * Retorna la capacidad que este ganadero tiene disponible para solidarizarse con vecinos.
   * @returns {number}
   */
  obtenerCapacidadSolidariaDisponible() {
    const finca = this.obtenerFincaPrincipal();
    if (!finca || !finca.tanque || !finca.tanque.permiteApoyoVecinos) return 0;
    return Math.min(finca.tanque.litrosReservadosVecinos, finca.tanque.obtenerEspacioDisponible());
  }

  /**
   * Realiza el análisis de rentabilidad: ingresos - costos.
   * @returns {{totalIngresos: number, totalCostos: number, utilidadNeta: number, esRentable: boolean}}
   */
  calcularBalanceFinanciero() {
    const totalIngresos = this.obtenerVentasAcumuladas();
    const totalCostos = this.costos.reduce((acum, c) => acum + c.monto, 0);
    const utilidadNeta = totalIngresos - totalCostos;
    return {
      totalIngresos,
      totalCostos,
      utilidadNeta,
      esRentable: utilidadNeta > 0,
    };
  }
}
