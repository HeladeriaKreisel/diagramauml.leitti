/**
 * @file Usuario.js
 * @description Clase base abstracta/general para los usuarios del sistema Leitti.app.
 */

export class Usuario {
  /**
   * @param {string} id - Identificador único del usuario (UUID o cédula).
   * @param {string} nombre - Nombre completo del usuario.
   * @param {string} telefono - Teléfono móvil de contacto.
   * @param {string} correo - Correo electrónico (opcional en entorno rural).
   * @param {string} rol - Rol dentro del sistema ('ganadero', 'comprador', 'cooperativa', 'administrador').
   */
  constructor(id, nombre, telefono, correo = '', rol = 'ganadero') {
    if (new.target === Usuario) {
      // Permitimos instanciarla o derivarla
    }
    this.id = String(id);
    this.nombre = String(nombre);
    this.telefono = String(telefono);
    this.correo = String(correo);
    this.rol = String(rol);
    this.activo = true;
    this.fechaRegistro = new Date();
  }

  /**
   * Actualiza los datos de contacto del usuario.
   * @param {string} nuevoTelefono
   * @param {string} nuevoCorreo
   */
  actualizarContacto(nuevoTelefono, nuevoCorreo) {
    if (nuevoTelefono) this.telefono = String(nuevoTelefono);
    if (nuevoCorreo) this.correo = String(nuevoCorreo);
  }

  desactivarCuenta() {
    this.activo = false;
  }
}
