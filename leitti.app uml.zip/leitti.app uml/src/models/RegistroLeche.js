/**
 * @file RegistroLeche.js
 * @description Modela el registro diario de producción de leche (módulo "Leche del día").
 */

export class RegistroLeche {
  /**
   * @param {string} id - Identificador del registro.
   * @param {number} litros - Litros ordeñados.
   * @param {string} jornada - Momento del ordeño ('manana', 'tarde').
   * @param {Date|string} fecha - Fecha del registro.
   * @param {string} destino - Destino inicial ('tanque_finca', 'venta_directa', 'autoconsumo').
   * @param {string} notas - Observaciones adicionales (ej: "ordeño sin problemas", "vaca en tratamiento").
   */
  constructor(id, litros, jornada = 'manana', fecha = new Date(), destino = 'tanque_finca', notas = '') {
    this.id = String(id);
    this.litros = Number(litros);
    this.jornada = String(jornada); // 'manana' | 'tarde'
    this.fecha = fecha instanceof Date ? fecha : new Date(fecha);
    this.destino = String(destino);
    this.notas = String(notas);
  }

  /**
   * Calcula el ingreso estimado de este registro según el precio base por litro.
   * @param {number} precioPorLitro - Precio en pesos colombianos ($ COP/L).
   * @returns {number}
   */
  calcularIngresoEstimado(precioPorLitro) {
    const precio = Number(precioPorLitro) || 0;
    return this.litros * precio;
  }
}
