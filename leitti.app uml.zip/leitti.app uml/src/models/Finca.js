/**
 * @file Finca.js
 * @description Modela la unidad productiva (finca o predio) del ganadero en Guasca.
 */

import { TanqueAlmacenamiento } from './TanqueAlmacenamiento.js';

export class Finca {
  /**
   * @param {string} id - Identificador del predio.
   * @param {string} nombre - Nombre de la finca (ej: "La Esperanza").
   * @param {string} vereda - Vereda (ej: "San Francisco", "La Trinidad").
   * @param {string} municipio - Municipio (por defecto "Guasca").
   * @param {number} areaHectareas - Extensión en hectáreas.
   * @param {TanqueAlmacenamiento|null} tanque - Tanque de almacenamiento asociado.
   */
  constructor(id, nombre, vereda = 'San Francisco', municipio = 'Guasca', areaHectareas = 0, tanque = null) {
    this.id = String(id);
    this.nombre = String(nombre);
    this.vereda = String(vereda);
    this.municipio = String(municipio);
    this.areaHectareas = Number(areaHectareas);
    this.tanque = tanque instanceof TanqueAlmacenamiento ? tanque : null;
  }

  /**
   * Asigna o actualiza el tanque de refrigeración de la finca.
   * @param {TanqueAlmacenamiento} tanque
   */
  asignarTanque(tanque) {
    if (!(tanque instanceof TanqueAlmacenamiento)) {
      throw new Error('El objeto asignado debe ser una instancia de TanqueAlmacenamiento.');
    }
    this.tanque = tanque;
  }

  /**
   * Retorna el espacio disponible del tanque de la finca.
   * @returns {number} Litros disponibles (0 si no tiene tanque registrado).
   */
  obtenerEspacioTanque() {
    return this.tanque ? this.tanque.obtenerEspacioDisponible() : 0;
  }
}
