/**
 * @file CostoProduccion.js
 * @description Modela los costos y egresos asociados a la producción lechera para calcular rentabilidad.
 */

export class CostoProduccion {
  /**
   * @param {string} id - Identificador del costo.
   * @param {string} concepto - Motivo del gasto (ej: "Bulto de concentrado", "Flete transporte cantinas").
   * @param {string} categoria - 'alimentacion', 'salud_veterinaria', 'transporte', 'energia', 'mano_de_obra', 'mantenimiento'.
   * @param {number} monto - Valor total del gasto en $ COP.
   * @param {Date|string} fecha - Fecha en que se incurrió en el costo.
   * @param {string} notas - Detalle o comprobante.
   */
  constructor(id, concepto, categoria, monto, fecha = new Date(), notas = '') {
    this.id = String(id);
    this.concepto = String(concepto);
    this.categoria = String(categoria);
    this.monto = Number(monto);
    this.fecha = fecha instanceof Date ? fecha : new Date(fecha);
    this.notas = String(notas);
  }
}
