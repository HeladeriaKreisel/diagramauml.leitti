/**
 * @file Comprador.js
 * @description Modela la empresa, intermediario o cooperativa que compra la leche.
 */

export class Comprador {
  /**
   * @param {string} id - Identificador único del comprador.
   * @param {string} nombre - Razón social o nombre del comprador.
   * @param {string} tipo - Tipo de entidad ('cooperativa', 'empresa_lactea', 'particular').
   * @param {string} telefono - Teléfono de contacto.
   * @param {number} precioBaseLitro - Precio de compra acordado por litro ($ COP).
   * @param {string} direccion - Punto de entrega o sede.
   */
  constructor(id, nombre, tipo = 'cooperativa', telefono = '', precioBaseLitro = 1800, direccion = 'Guasca') {
    this.id = String(id);
    this.nombre = String(nombre);
    this.tipo = String(tipo);
    this.telefono = String(telefono);
    this.precioBaseLitro = Number(precioBaseLitro);
    this.direccion = String(direccion);
  }

  /**
   * Actualiza el precio acordado por litro.
   * @param {number} nuevoPrecio
   */
  actualizarPrecio(nuevoPrecio) {
    if (Number(nuevoPrecio) <= 0) {
      throw new Error('El precio por litro debe ser mayor a 0.');
    }
    this.precioBaseLitro = Number(nuevoPrecio);
  }
}
