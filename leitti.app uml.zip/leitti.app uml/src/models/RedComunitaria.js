/**
 * @file RedComunitaria.js
 * @description Modela la red de colaboración y apoyo mutuo entre ganaderos de la vereda o sector.
 */

import { SolicitudApoyo } from './SolicitudApoyo.js';

export class RedComunitaria {
  /**
   * @param {string} id - Identificador de la red.
   * @param {string} nombreSector - Nombre de la comunidad (ej: "Red San Francisco - Guasca").
   */
  constructor(id, nombreSector = 'Red San Francisco - Guasca') {
    this.id = String(id);
    this.nombreSector = String(nombreSector);
    /** @type {Array<import('./Ganadero.js').Ganadero>} */
    this.miembros = [];
    /** @type {Array<SolicitudApoyo>} */
    this.solicitudes = [];
  }

  /**
   * Vincula a un ganadero a la red comunitaria.
   * @param {import('./Ganadero.js').Ganadero} ganadero
   */
  unirMiembro(ganadero) {
    if (!this.miembros.some((m) => m.id === ganadero.id)) {
      this.miembros.push(ganadero);
    }
  }

  /**
   * Busca vecinos que tengan tanque habilitado para auxilio y con suficiente espacio libre.
   * @param {number} litrosNecesarios
   * @param {string} idExcluir - ID del propio solicitante
   * @returns {Array<import('./Ganadero.js').Ganadero>}
   */
  buscarVecinosConCapacidad(litrosNecesarios, idExcluir = '') {
    return this.miembros.filter((miembro) => {
      if (miembro.id === idExcluir) return false;
      const capacidadSolidaria = miembro.obtenerCapacidadSolidariaDisponible();
      return capacidadSolidaria >= litrosNecesarios;
    });
  }

  /**
   * Publica una alerta de auxilio en la red.
   * @param {SolicitudApoyo} solicitud
   */
  publicarSolicitud(solicitud) {
    if (!(solicitud instanceof SolicitudApoyo)) {
      throw new Error('Debe ser una instancia de SolicitudApoyo.');
    }
    this.solicitudes.push(solicitud);
    return solicitud;
  }

  /**
   * Retorna las solicitudes pendientes en el sector.
   * @returns {Array<SolicitudApoyo>}
   */
  obtenerSolicitudesPendientes() {
    return this.solicitudes.filter((s) => s.estado === 'pendiente');
  }
}
